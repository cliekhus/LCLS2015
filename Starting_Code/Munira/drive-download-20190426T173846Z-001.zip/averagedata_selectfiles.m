clear all
hold off
Runs=[375, 376, 377, 378, 379, 381, 382, 384, 386];

dataon=[];
dataoff=[];
rtheta=[];

for aa=1:length(Runs);
    str1=num2str(Runs(aa));
    dataon=[dataon; load(strcat('delta_T_cee',str1,'.mat'),'Rowland_On')];
    dataoff=[dataoff; load(strcat('delta_T_cee',str1,'.mat'),'Rowland_off')];
    energy= load(strcat('delta_T_cee',str1,'.mat'),'monoaxis');
    times=load(strcat('delta_T_cee',str1,'.mat'),'Timesaxis');
end
% figure
% plot(Timesmat(1,:), datamaton)
%% Plotting all the Rowland off
for aa=1:length(Runs);
    y=dataoff(aa).Rowland_off;
    doff(:,aa)=(y);
    plot(energy.monoaxis, y);
    hold on
end

hold off

%% Plotting all the Rowland on

for aa=1:length(Runs);
    y=dataon(aa).Rowland_On;
    don(:,:,aa)=y;
end

don_sum=sum(don,3);
contourf(energy.monoaxis, times.Timesaxis, don_sum, 30)



%% Plotting don and doff

figure
plot(energy.monoaxis, nanmean(don_sum(4:7,:),1), energy.monoaxis,sum(doff,2).*3)
figure
plot(energy.monoaxis, (nanmean(don_sum(4:7,:),1)-sum(doff,2)')./(sum(doff,2)'))


%% First smoothing and then taking the difference

dataonsm=sgolayfilt(nanmean(don_sum(4:7,:),1), 2,5);
dataonavg=nanmean(don_sum(4:7,:),1);
doffavg=sum(doff,2,'double');
dataoffsm=sgolayfilt(doffavg, 2,5);
deltaT=(dataonavg-doffavg')./(doffavg');
deltaTsm=(dataonsm-dataoffsm')./(dataoffsm');
figure
plot(energy.monoaxis, dataonsm, energy.monoaxis,dataoffsm)
figure
plot(energy.monoaxis, (dataonsm-dataoffsm')./(dataoffsm'),energy.monoaxis, (dataonavg-doffavg')./(doffavg'),energy.monoaxis,zeros(length(energy.monoaxis)))



%% Saving file

save('FsCEEavg.mat','energy','doffavg','dataoffsm','deltaT','deltaTsm');

%%

